#include <iostream>
#include <cmath>
#include <cstdlib>
#include <cstring>

//Declaration of functions

void usage (int argc, char *argv[]);
int AddSquares (int parameter);
int AdditionOfSquares (int parameter);