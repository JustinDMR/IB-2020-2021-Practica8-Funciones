#include "string_statistics.h"

int main (){
  std::vector <std::string> random_word = {"abracadabra", "Useless", "technology", "centuries", "banana", "good morning", "Follow your passion", "peanut head", "programming god", "subscribe to my youtube channel"};
  StringCharacteristics (random_word);
}