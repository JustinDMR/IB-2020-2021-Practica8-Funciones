#include <iostream>
#include <string.h>
#include <vector>

//Declaration of functions

int IsPrime(int position);
void usage (int argc, char *argv[]);