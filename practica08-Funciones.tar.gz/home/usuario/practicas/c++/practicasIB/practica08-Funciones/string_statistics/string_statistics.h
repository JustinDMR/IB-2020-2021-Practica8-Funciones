#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>

//Declaration of functions

void StringCharacteristics (std::vector <std::string> random_word);