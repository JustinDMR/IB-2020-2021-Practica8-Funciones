#include <iostream>

bool IsPrime(int number);