#include "modificacion.h"

int main(int argc, char*argv[]) {
  std::string parameter {argv[1]};
  int position = std::stoi (parameter);
  int prime_number;
  int current_number;
  int sum = 0;
  for(int i = 0; i < position; ++i) {
    do {
      ++current_number;
    }
    while (!IsPrime(current_number));
    if (IsPrime(current_number)) {
      prime_number = current_number;
      ++current_number;
      sum += current_number;
    }
  }
  std::cout << "The average of the first "<< parameter << " prime numbers is: " << sum / position << std::endl;
  return 0;
}